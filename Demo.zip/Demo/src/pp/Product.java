package pp;

public class Product {
private String pid;
private String name;
private int price;
private String cat;
private String cmp;
public String getPid() {
	return pid;
}
public void setPid(String pid) {
	this.pid = pid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getCat() {
	return cat;
}
public void setCat(String cat) {
	this.cat = cat;
}
public String getCmp() {
	return cmp;
}
public void setCmp(String cmp) {
	this.cmp = cmp;
}

}
